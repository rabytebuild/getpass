<?php

namespace BookneticApp\Providers\Core;

class CapabilitiesException extends \Exception
{

}