<?php

namespace BookneticApp\Providers\UI;

use BookneticApp\Providers\UI\Abstracts\AbstractTabItemUI;

class TabItemUI extends AbstractTabItemUI
{
    protected static $lastItemPriority = 0;
}