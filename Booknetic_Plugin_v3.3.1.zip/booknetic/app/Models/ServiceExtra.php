<?php

namespace BookneticApp\Models;

use BookneticApp\Providers\DB\Model;

class ServiceExtra extends Model
{



}