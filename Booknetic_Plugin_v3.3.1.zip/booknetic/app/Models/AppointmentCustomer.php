<?php

namespace BookneticApp\Models;

/**
 * @deprecated
 */
class AppointmentCustomer extends \BookneticApp\Providers\DB\Model
{

}