<?php

namespace BookneticApp\Frontend\Controller;

use BookneticApp\Providers\Core\FrontendAjax;
use BookneticApp\Providers\Helpers\Helper;

class SigninAjax extends FrontendAjax
{
    public function signin()
    {
        $email      = Helper::_post('email', '', 'email');
        $password   = Helper::_post('password', '', 'string');

        if ( empty($email) || empty($password) )
        {
            return $this->response(false, bkntc__('Please enter your email and password correctly!'));
        }

        $user = get_user_by('email', $email);

        if( !$user || !wp_check_password( $password, $user->data->user_pass, $user->ID ) )
        {
            return $this->response(false, bkntc__('Email or password is incorrect!'));
        }

        if( in_array( 'booknetic_saas_tenant', $user->roles ) )
        {
//            $tenantInfo = Tenant::where('email', $email)->fetch();
//            if( !$tenantInfo || empty( $tenantInfo->domain ) )
//            {
//                return $this->response( false, bkntc__('To access your account, you must first complete your registration. Please log in to your email to complete your registration.') );
//            }
        }

        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID );
        do_action( 'wp_login', $user->user_login, $user );

        return $this->response( true, [
            'url'   => Helper::getURLOfUsersDashboard( $user )
        ]);
    }

}