<?php defined( 'ABSPATH' ) or die(); ?>
<span class="text-secondary"><?php echo bkntc__('No settings found for this step.')?></span>