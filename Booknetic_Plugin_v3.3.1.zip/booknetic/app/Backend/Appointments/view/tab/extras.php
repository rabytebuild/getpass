<?php defined( 'ABSPATH' ) or die(); ?>

<div class="text-secondary font-size-14 text-center"><?php echo bkntc__( 'No extras found' ) ?></div>
